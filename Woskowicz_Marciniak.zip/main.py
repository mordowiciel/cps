#!/usr/bin/env python

# coding: utf-8
from main_view import BasicView

basicView = BasicView()


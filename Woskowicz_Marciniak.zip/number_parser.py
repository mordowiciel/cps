def parse(number_as_string):
  return float(number_as_string)
  # number_as_string = number_as_string.replace(" ", "")
  # print number_as_string
  # return complex(number_as_string)
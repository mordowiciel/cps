#!/usr/bin/env python

# coding: utf-8
from main_view import BasicView
from signal_generator import *
from sampling import *
import matplotlib.pyplot as plt
import numpy as np
import quantization as qz
import sampling_quantz_util as squ

basicView = BasicView()
